class UserController {
  constructor() {
    this.users = [];
  }

  add(user) {
    this.users.push(user);
    return user;
  }

  remove(id) {
    this.users = this.users.filter(user => user.id !== id);
  }

  findByEmail(email) {
    return this.users.find(user => user.email === email);
  }

  findById(id) {
    return this.users.find(user => user.id === id);
  }
}

module.exports = UserController;
