const { divide, multiply } = require("../src/calculator");

test("divide two numbers correctly", () => {
  expect(divide(10, 2)).toBe(5);
});

test("divide throws error when dividing by zero", () => {
  expect(() => divide(10, 0)).toThrow("Cannot divide by zero");
});

test("multiply two numbers correctly", () => {
  expect(multiply(3, 4)).toBe(12);
});

test("multiply with zero", () => {
  expect(multiply(5, 0)).toBe(0);
});
