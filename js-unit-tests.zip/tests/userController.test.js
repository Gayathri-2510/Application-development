const UserController = require("../src/userController");

let controller;

beforeEach(() => {
  controller = new UserController();
  controller.add({ id: 1, email: "test1@email.com" });
  controller.add({ id: 2, email: "test2@email.com" });
});

test("add user", () => {
  const user = controller.add({ id: 3, email: "test3@email.com" });
  expect(user.email).toBe("test3@email.com");
});

test("remove user by id", () => {
  controller.remove(1);
  expect(controller.findById(1)).toBeUndefined();
});

test("find user by email", () => {
  expect(controller.findByEmail("test1@email.com").id).toBe(1);
});

test("return undefined if email not found", () => {
  expect(controller.findByEmail("none@email.com")).toBeUndefined();
});

test("find user by id", () => {
  expect(controller.findById(2).email).toBe("test2@email.com");
});

test("return undefined if id not found", () => {
  expect(controller.findById(99)).toBeUndefined();
});
